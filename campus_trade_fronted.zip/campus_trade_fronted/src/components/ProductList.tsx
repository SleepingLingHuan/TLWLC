import React, { useState } from 'react';
import { List, Card, Tag, Button, Modal, message } from 'antd';
import { ShoppingCartOutlined, SwapOutlined } from '@ant-design/icons';

interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  image: string;
  tags: string[];
  seller: {
    id: number;
    name: string;
  };
}

// 模拟数据库 图片在网上随便找一张
const mockProducts: Product[] = [
  {
    id: 1,
    name: '二手笔记本电脑',
    price: 2999,
    description: '使用一年的笔记本，性能良好，无维修史',
    image: 'https://picsum.photos/300/200',
    tags: ['电子产品', '学习'],
    seller: {
      id: 1,
      name: '张三'
    }
  },
  {
    id: 2,
    name: '专业课教材',
    price: 30,
    description: '计算机网络教材，九成新',
    image: 'https://picsum.photos/300/200',
    tags: ['书籍', '学习'],
    seller: {
      id: 2,
      name: '李四'
    }
  },
  {
    id: 3,
    name: '自行车',
    price: 399,
    description: '二手自行车，性能良好',
    image: 'https://picsum.photos/300/200',
    tags: ['交通工具', '生活'],
    seller: {
      id: 3,
      name: '王五'
    }
  },
  {
    id: 4,
    name: '篮球',
    price: 50,
    description: '耐克篮球，使用三个月',
    image: 'https://picsum.photos/300/200',
    tags: ['运动', '生活'],
    seller: {
      id: 4,
      name: '赵六'
    }
  }
];

const ProductList: React.FC = () => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [actionType, setActionType] = useState<'buy' | 'exchange' | null>(null);

  const handleAction = (product: Product, type: 'buy' | 'exchange') => {
    setSelectedProduct(product);
    setActionType(type);
    setIsModalVisible(true);
  };

  const handleConfirm = () => {
    if (!selectedProduct) return;
    message.success(actionType === 'buy' ? '购买请求已发送' : '置换请求已发送');
    setIsModalVisible(false);
    setSelectedProduct(null);
    setActionType(null);
  };

  return (
    <div style={{ padding: '24px' }}>
      <List
        grid={{ gutter: 16, xs: 1, sm: 2, md: 3, lg: 3, xl: 4, xxl: 4 }}
        dataSource={mockProducts}
        renderItem={(product) => (
          <List.Item>
            <Card
              hoverable
              cover={<img alt={product.name} src={product.image} style={{ height: 200, objectFit: 'cover' }} />}
              actions={[
                <Button 
                  type="primary" 
                  icon={<ShoppingCartOutlined />}
                  onClick={() => handleAction(product, 'buy')}
                >
                  购买
                </Button>,
                <Button 
                  type="default" 
                  icon={<SwapOutlined />}
                  onClick={() => handleAction(product, 'exchange')}
                >
                  置换
                </Button>
              ]}
            >
              <Card.Meta
                title={<span style={{ fontSize: '18px', color: '#1890ff' }}>{product.name}</span>}
                description={
                  <div>
                    <p style={{ fontSize: '20px', color: '#f5222d', marginBottom: '8px' }}>
                      ¥{product.price}
                    </p>
                    <p style={{ marginBottom: '8px' }}>{product.description}</p>
                    <p style={{ marginBottom: '8px' }}>卖家: {product.seller.name}</p>
                    <div>
                      {product.tags.map((tag) => (
                        <Tag key={tag} color="blue" style={{ marginBottom: '4px' }}>{tag}</Tag>
                      ))}
                    </div>
                  </div>
                }
              />
            </Card>
          </List.Item>
        )}
      />

      <Modal
        title={actionType === 'buy' ? '确认购买' : '确认置换'}
        open={isModalVisible}
        onOk={handleConfirm}
        onCancel={() => {
          setIsModalVisible(false);
          setSelectedProduct(null);
          setActionType(null);
        }}
      >
        <p>您确定要{actionType === 'buy' ? '购买' : '置换'}这个商品吗？</p>
        {selectedProduct && (
          <div>
            <p>商品名称: {selectedProduct.name}</p>
            <p>价格: ¥{selectedProduct.price}</p>
            <p>卖家: {selectedProduct.seller.name}</p>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default ProductList; 