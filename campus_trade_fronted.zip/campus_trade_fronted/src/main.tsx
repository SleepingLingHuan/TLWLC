import React from 'react';
import ReactDOM from 'react-dom/client';
import { ConfigProvider } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import ProductList from './components/ProductList';
import 'antd/dist/reset.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ConfigProvider locale={zhCN}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '24px' }}>
        <h1 style={{ textAlign: 'center', marginBottom: '32px' }}>校园二手交易平台</h1>
        <ProductList />
      </div>
    </ConfigProvider>
  </React.StrictMode>
); 