<template>
  <div class="product-list">
    <!-- 商品列表 -->
    <a-list
      :grid="{ gutter: 16, xs: 1, sm: 2, md: 2, lg: 3, xl: 4, xxl: 4 }"
      :data-source="products"
      :loading="loading"
    >
      <template #renderItem="{ item }">
        <a-list-item>
          <a-card
            hoverable
            class="product-card"
          >
            <template #cover>
              <div class="card-image-container">
                <img :alt="item.name" :src="item.image" class="product-image" />
                <div class="price-tag">¥{{ item.price }}</div>
              </div>
            </template>
            
            <!-- 标签区域 - 图片下方 -->
            <div class="product-tags">
              <a-tag v-for="tag in item.tags" :key="tag" color="blue">
                {{ tag }}
              </a-tag>
            </div>
            
            <template #title>
              <div class="product-title">{{ item.name }}</div>
            </template>
            
            <template #description>
              <div class="product-details">
                <div class="seller-info">
                  <a-avatar size="small" :style="{ backgroundColor: getAvatarColor(item.seller.id) }">
                    {{ item.seller.name.substring(0, 1) }}
                  </a-avatar>
                  <span class="seller-name">{{ item.seller.name }}</span>
                </div>
                <p class="product-description">{{ item.description }}</p>
              </div>
            </template>
            
            <template #actions>
              <a-button 
                type="primary" 
                @click="() => handleAction(item, 'buy')"
                :disabled="!item.canBuy"
                :title="!item.canBuy ? '该商品不可购买' : ''"
              >
                <template #icon><ShoppingCartOutlined /></template>
                购买
              </a-button>
              <a-button 
                @click="() => handleAction(item, 'exchange')"
                :disabled="!item.canExchange"
                :title="!item.canExchange ? '该商品不可置换' : ''"
              >
                <template #icon><SwapOutlined /></template>
                置换
              </a-button>
            </template>
          </a-card>
        </a-list-item>
      </template>
    </a-list>

    <!-- 空状态 -->
    <a-empty v-if="products.length === 0 && !loading" description="没有找到相关商品" />

    <!-- 模态框 -->
    <a-modal
      :title="actionType === 'buy' ? '确认购买' : '确认置换'"
      v-model:visible="isModalVisible"
      @ok="handleConfirm"
      @cancel="handleCancel"
      okText="确定"
      cancelText="取消"
    >
      <p>您确定要{{ actionType === 'buy' ? '购买' : '置换' }}这个商品吗？</p>
      <div v-if="selectedProduct" class="modal-product-info">
        <p><strong>商品名称:</strong> {{ selectedProduct.name }}</p>
        <p><strong>价格:</strong> ¥{{ selectedProduct.price }}</p>
        <p><strong>卖家:</strong> {{ selectedProduct.seller.name }}</p>
      </div>
    </a-modal>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { ShoppingCartOutlined, SwapOutlined } from '@ant-design/icons-vue'
import axios from 'axios'
import { message } from 'ant-design-vue'

const props = defineProps({
  searchQuery: {
    type: String,
    default: ''
  }
})

const products = ref([])
const loading = ref(true)
const selectedProduct = ref(null)
const isModalVisible = ref(false)
const actionType = ref(null)

// 前端模拟数据（仅在API调用失败时使用）
const mockProducts = [
  {
    id: 1,
    name: '二手笔记本电脑',
    price: 2999,
    description: '使用一年的笔记本，性能良好，无维修史',
    image: 'https://picsum.photos/300/200?random=1',
    tags: ['电子产品', '学习'],
    canBuy: true,
    canExchange: false,
    seller: {
      id: 1,
      name: '张三'
    }
  },
  {
    id: 2,
    name: '专业课教材',
    price: 30,
    description: '计算机网络教材，九成新',
    image: 'https://picsum.photos/300/200?random=2',
    tags: ['书籍', '学习'],
    canBuy: true,
    canExchange: true,
    seller: {
      id: 2,
      name: '李四'
    }
  },
  {
    id: 3,
    name: '自行车',
    price: 399,
    description: '二手自行车，性能良好',
    image: 'https://picsum.photos/300/200?random=3',
    tags: ['交通工具', '生活'],
    canBuy: true,
    canExchange: false,
    seller: {
      id: 3,
      name: '王五'
    }
  },
  {
    id: 4,
    name: '篮球',
    price: 50,
    description: '耐克篮球，使用三个月',
    image: 'https://picsum.photos/300/200?random=4',
    tags: ['运动', '生活'],
    canBuy: false,
    canExchange: true,
    seller: {
      id: 4,
      name: '赵六'
    }
  },
  {
    id: 5,
    name: '小米手机',
    price: 1299,
    description: '小米10，使用8个月，外观完好',
    image: 'https://picsum.photos/300/200?random=5',
    tags: ['电子产品', '数码'],
    canBuy: true,
    canExchange: true,
    seller: {
      id: 5,
      name: '周七'
    }
  },
  {
    id: 6,
    name: '耳机',
    price: 129,
    description: '蓝牙耳机，音质好，续航长',
    image: 'https://picsum.photos/300/200?random=6',
    tags: ['电子产品', '数码'],
    canBuy: false,
    canExchange: true,
    seller: {
      id: 6,
      name: '吴八'
    }
  }
]

const fetchProducts = async () => {
  try {
    loading.value = true
    // 调用后端 API 获取商品列表，如果有搜索关键词，则传递给后端
    const url = 'http://localhost:3001/api/products' + (props.searchQuery ? `?keyword=${encodeURIComponent(props.searchQuery)}` : '')
    const response = await axios.get(url)
    if (response.data) {
      products.value = response.data
    }
  } catch (error) {
    console.error('获取商品列表失败:', error)
    message.error('获取商品列表失败，使用本地模拟数据')
    // 如果有搜索关键词，则过滤模拟数据
    if (props.searchQuery) {
      const query = props.searchQuery.toLowerCase()
      products.value = mockProducts.filter(product => 
        product.name.toLowerCase().includes(query) || 
        product.description.toLowerCase().includes(query) ||
        product.tags.some(tag => tag.toLowerCase().includes(query))
      )
    } else {
      products.value = mockProducts // 使用全部模拟数据
    }
  } finally {
    loading.value = false
  }
}

const handleAction = (product, type) => {
  // 如果商品不支持该交易方式，直接返回
  if ((type === 'buy' && !product.canBuy) || (type === 'exchange' && !product.canExchange)) {
    return
  }
  
  selectedProduct.value = product
  actionType.value = type
  isModalVisible.value = true
}

const handleConfirm = async () => {
  if (!selectedProduct.value) return

  try {
    // 调用后端 API
    await axios.post('http://localhost:3001/api/orders', {
      productId: selectedProduct.value.id,
      type: actionType.value
    })
    message.success(actionType.value === 'buy' ? '购买请求已发送' : '置换请求已发送')
    handleCancel()
  } catch (error) {
    console.error('操作失败:', error)
    message.error('操作失败，请重试')
  }
}

const handleCancel = () => {
  isModalVisible.value = false
  selectedProduct.value = null
  actionType.value = null
}

// 根据卖家ID生成头像颜色
const getAvatarColor = (id) => {
  const colors = ['#1890ff', '#52c41a', '#fa8c16', '#722ed1', '#eb2f96', '#f5222d']
  return colors[id % colors.length]
}

// 监听搜索关键词变化，重新获取数据
watch(() => props.searchQuery, () => {
  fetchProducts()
})

onMounted(() => {
  fetchProducts()
})
</script>

<style scoped>
.product-list {
  padding: 24px;
}

.product-card {
  height: 100%;
  display: flex;
  flex-direction: column;
  margin-bottom: 16px;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.09);
}

.card-image-container {
  overflow: hidden;
  height: 220px;
  position: relative;
}

.product-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.5s;
}

.product-card:hover .product-image {
  transform: scale(1.08);
}

.price-tag {
  position: absolute;
  top: 12px;
  right: 12px;
  background-color: rgba(245, 34, 45, 0.85);
  color: white;
  padding: 4px 8px;
  border-radius: 4px;
  font-weight: bold;
  font-size: 18px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
}

.product-tags {
  padding: 8px 16px;
  background-color: #f8f8f8;
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.product-title {
  font-size: 18px;
  color: #1890ff;
  margin-top: 4px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.seller-info {
  display: flex;
  align-items: center;
  margin: 8px 0;
  padding: 6px 0;
  border-bottom: 1px dashed #f0f0f0;
}

.seller-name {
  margin-left: 8px;
  font-size: 14px;
  color: #555;
}

.product-description {
  color: #555;
  margin: 8px 0;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 14px;
}

.modal-product-info {
  padding: 10px;
  background: #f5f5f5;
  border-radius: 4px;
}
</style> 