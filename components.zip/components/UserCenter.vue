<template>
  <div class="user-center">
    <a-tabs default-active-key="1">
      <a-tab-pane key="1" tab="个人信息">
        <a-form :model="userForm" layout="vertical">
          <a-form-item label="头像">
            <a-upload
              v-model:file-list="fileList"
              action="http://localhost:3001/api/upload"
              list-type="picture-card"
              :show-upload-list="false"
              @preview="handlePreview"
              @change="handleChange"
            >
              <div v-if="userForm.avatar">
                <img :src="userForm.avatar" alt="avatar" style="width: 100%" />
              </div>
              <div v-else>
                <UserOutlined />
                <div class="ant-upload-text">上传头像</div>
              </div>
            </a-upload>
          </a-form-item>
          
          <a-form-item label="昵称" name="nickname">
            <a-input v-model:value="userForm.nickname" placeholder="请输入您的昵称" />
          </a-form-item>
          
          <a-form-item label="联系方式" name="contact">
            <a-input v-model:value="userForm.contact" placeholder="请输入您的联系方式" />
          </a-form-item>
          
          <a-form-item>
            <a-button type="primary" @click="saveUserInfo">保存信息</a-button>
          </a-form-item>
        </a-form>
      </a-tab-pane>
      
      <a-tab-pane key="2" tab="交易记录">
        <a-table :columns="tradeColumns" :data-source="tradeRecords" rowKey="id">
          <template #bodyCell="{ column, record }">
            <template v-if="column.dataIndex === 'status'">
              <a-tag :color="record.status === 'completed' ? 'green' : (record.status === 'pending' ? 'orange' : 'red')">
                {{ statusMap[record.status] }}
              </a-tag>
            </template>
            <template v-if="column.dataIndex === 'type'">
              <a-tag :color="record.type === 'buy' ? 'blue' : 'purple'">
                {{ record.type === 'buy' ? '购买' : '置换' }}
              </a-tag>
            </template>
          </template>
        </a-table>
      </a-tab-pane>
      
      <a-tab-pane key="3" tab="上传物品">
        <a-form :model="productForm" layout="vertical">
          <a-form-item label="物品名称" name="name" :rules="[{ required: true, message: '请输入物品名称' }]">
            <a-input v-model:value="productForm.name" placeholder="请输入物品名称" />
          </a-form-item>
          
          <a-form-item label="物品图片" name="image">
            <a-upload
              v-model:file-list="productImageList"
              action="http://localhost:3001/api/upload"
              list-type="picture-card"
              @preview="handlePreview"
              @change="handleProductImageChange"
            >
              <div v-if="productImageList.length < 1">
                <PlusOutlined />
                <div style="margin-top: 8px">上传</div>
              </div>
            </a-upload>
          </a-form-item>
          
          <a-form-item label="物品价格" name="price" :rules="[{ required: true, message: '请输入物品价格' }]">
            <a-input-number v-model:value="productForm.price" :min="0" placeholder="请输入物品价格" style="width: 100%" />
          </a-form-item>
          
          <a-form-item label="物品描述" name="description">
            <a-textarea v-model:value="productForm.description" placeholder="请输入物品描述" :rows="4" />
          </a-form-item>
          
          <a-form-item label="交易方式" name="tradeType">
            <a-checkbox-group v-model:value="productForm.tradeTypes">
              <a-checkbox value="buy">可购买</a-checkbox>
              <a-checkbox value="exchange">可置换</a-checkbox>
            </a-checkbox-group>
          </a-form-item>
          
          <a-form-item label="物品标签" name="tags">
            <a-checkbox-group v-model:value="productForm.tags" :max="3">
              <a-checkbox value="电子产品">电子产品</a-checkbox>
              <a-checkbox value="书籍">书籍</a-checkbox>
              <a-checkbox value="学习">学习</a-checkbox>
              <a-checkbox value="运动">运动</a-checkbox>
              <a-checkbox value="生活">生活</a-checkbox>
              <a-checkbox value="交通工具">交通工具</a-checkbox>
              <a-checkbox value="服装">服装</a-checkbox>
              <a-checkbox value="数码">数码</a-checkbox>
              <a-checkbox value="家具">家具</a-checkbox>
              <a-checkbox value="其他">其他</a-checkbox>
            </a-checkbox-group>
            <div class="tags-hint">最多选择3个标签</div>
          </a-form-item>
          
          <a-form-item>
            <a-button type="primary" @click="uploadProduct">发布物品</a-button>
          </a-form-item>
        </a-form>
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { UserOutlined, PlusOutlined } from '@ant-design/icons-vue'
import axios from 'axios'
import { message } from 'ant-design-vue'

// 用户表单数据
const userForm = reactive({
  avatar: '',
  nickname: '',
  contact: ''
})

// 物品表单数据
const productForm = reactive({
  name: '',
  price: 0,
  description: '',
  tradeTypes: [], // 'buy', 'exchange'
  tags: []
})

// 文件上传相关
const fileList = ref([])
const productImageList = ref([])

// 交易记录相关
const statusMap = {
  'pending': '待处理',
  'completed': '已完成',
  'canceled': '已取消'
}

const tradeColumns = [
  {
    title: '订单编号',
    dataIndex: 'id',
    key: 'id'
  },
  {
    title: '商品名称',
    dataIndex: 'productName',
    key: 'productName'
  },
  {
    title: '价格',
    dataIndex: 'price',
    key: 'price',
    customRender: ({ text }) => `¥${text}`
  },
  {
    title: '交易类型',
    dataIndex: 'type',
    key: 'type'
  },
  {
    title: '交易状态',
    dataIndex: 'status',
    key: 'status'
  },
  {
    title: '交易时间',
    dataIndex: 'time',
    key: 'time'
  }
]

const tradeRecords = ref([])

// 前端模拟数据（仅在API调用失败时使用）
const mockTradeRecords = [
  {
    id: '1',
    productName: '二手笔记本电脑',
    price: 2999,
    type: 'buy',
    status: 'completed',
    time: '2025-03-19 14:30:22'
  },
  {
    id: '2',
    productName: '自行车',
    price: 399,
    type: 'exchange',
    status: 'pending',
    time: '2025-03-20 09:15:48'
  }
]

// 头像预览
const handlePreview = () => {}

// 头像变更
const handleChange = (info) => {
  if (info.file.status === 'done') {
    userForm.avatar = info.file.response.url
    message.success('头像上传成功')
  }
}

// 商品图片变更
const handleProductImageChange = (info) => {
  if (info.file.status === 'done') {
    productForm.image = info.file.response.url
    message.success('图片上传成功')
  }
}

// 保存用户信息的接口
const saveUserInfo = async () => {
  try {
    await axios.post('http://localhost:3001/api/user/update', userForm)
    message.success('个人信息保存成功')
  } catch (error) {
    console.error('保存失败:', error)
    message.error('保存失败，请重试')
  }
}

// 上传物品的相关接口
const uploadProduct = async () => {
  if (!productForm.name || !productForm.price || !productForm.tradeTypes.length) {
    message.error('请填写必要信息')
    return
  }
  
  if (!productForm.image) {
    message.error('请上传商品图片')
    return
  }
  
  if (productForm.tags.length > 3) {
    message.error('最多选择3个标签')
    return
  }
  
  try {
    const productData = {
      ...productForm,
      canBuy: productForm.tradeTypes.includes('buy'),
      canExchange: productForm.tradeTypes.includes('exchange')
    }
    
    await axios.post('http://localhost:3001/api/products', productData)
    message.success('物品发布成功')
    
    // 重置表单
    Object.keys(productForm).forEach(key => {
      if (Array.isArray(productForm[key])) {
        productForm[key] = []
      } else if (typeof productForm[key] === 'number') {
        productForm[key] = 0
      } else {
        productForm[key] = ''
      }
    })
    productImageList.value = []
  } catch (error) {
    console.error('发布失败:', error)
    message.error('发布失败，请重试')
  }
}

// 获取用户信息
const fetchUserInfo = async () => {
  try {
    const response = await axios.get('http://localhost:3001/api/user')
    if (response.data) {
      userForm.avatar = response.data.avatar
      userForm.nickname = response.data.nickname
      userForm.contact = response.data.contact
      
      if (response.data.avatar) {
        fileList.value = [
          {
            uid: '-1',
            name: 'avatar.png',
            status: 'done',
            url: response.data.avatar
          }
        ]
      }
    }
  } catch (error) {
    console.error('获取用户信息失败:', error)
    message.error('获取用户信息失败')
    
    // 设置一些默认值
    userForm.nickname = '用户'
    userForm.contact = '请设置联系方式'
  }
}

// 获取交易记录
const fetchTradeRecords = async () => {
  try {
    const response = await axios.get('http://localhost:3001/api/orders')
    if (response.data) {
      tradeRecords.value = response.data
    } else {
      tradeRecords.value = []
    }
  } catch (error) {
    console.error('获取交易记录失败:', error)
    message.error('获取交易记录失败，使用本地模拟数据')
    tradeRecords.value = mockTradeRecords // 使用模拟数据
  }
}

onMounted(() => {
  fetchUserInfo()
  fetchTradeRecords()
})
</script>

<style scoped>
.user-center {
  padding: 16px;
}

.ant-upload-text {
  margin-top: 8px;
}

.tags-hint {
  color: #999;
  font-size: 12px;
  margin-top: 4px;
}
</style> 